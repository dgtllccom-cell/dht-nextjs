import Link from "next/link";
import type { Route } from "next";
import { Building2, MapPin, Settings, SlidersHorizontal } from "lucide-react";

const settingsItems = [
  {
    title: "Company Setup",
    description: "Company incorporation, owner identification, contacts, and registrations.",
    href: "/dashboard/settings/company-setup" as Route,
    icon: Building2
  },
  {
    title: "Location Setup",
    description: "Country, state, city, zip code, currency, and status master data.",
    href: "/dashboard/settings/location-setup" as Route,
    icon: MapPin
  },
  {
    title: "Management",
    description: "Draft parameter area for registration, contract, country, customer, and document types.",
    href: "/dashboard/settings/management" as Route,
    icon: SlidersHorizontal
  }
];

export default function SettingsPage() {
  return (
    <div className="space-y-6">
      <div>
        <p className="text-xs font-semibold uppercase tracking-[0.24em] text-primary">Workspace</p>
        <h1 className="mt-1 text-2xl font-semibold tracking-tight">Settings</h1>
        <p className="text-sm text-muted-foreground">
          Setup screens used by branch, company, account, and permission workflows.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {settingsItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className="rounded-lg border bg-card p-5 transition hover:border-primary hover:shadow-sm"
          >
            <item.icon className="mb-4 h-5 w-5 text-primary" aria-hidden />
            <h2 className="font-semibold">{item.title}</h2>
            <p className="mt-2 text-sm leading-6 text-muted-foreground">{item.description}</p>
          </Link>
        ))}
      </div>

      <section className="rounded-lg border bg-card p-5">
        <div className="flex items-start gap-3">
          <Settings className="mt-1 h-5 w-5 text-primary" aria-hidden />
          <div>
            <h2 className="font-semibold">Configuration area</h2>
            <p className="mt-1 text-sm leading-6 text-muted-foreground">
              Company, location, and management draft setup are available here. Management parameters
              can be connected to their forms in the next step.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
