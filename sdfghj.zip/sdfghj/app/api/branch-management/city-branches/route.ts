import { NextResponse } from "next/server";
import { createCityBranchSchema } from "@/features/branch-management/validation";
import { ErpAuthError, requireErpSession } from "@/lib/auth/session";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { auditApiAction } from "@/lib/api/audit";

function isUuid(value: string) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}

const cityBranchSelect =
  "id,country_id,country_branch_id,city_name,name,code,local_currency,status,state_province_id,city_id,area_location_id,address,phone,email,company_id,owner_name,contacts,documents,permission_template,permission_grants,created_at,updated_at";

const cityBranchFallbackSelect =
  "id,country_id,country_branch_id,city_name,name,code,local_currency,status,state_province_id,city_id,area_location_id,address,phone,email,company_id,owner_name,contacts,documents,created_at,updated_at";

function isMissingOptionalColumn(message: string) {
  return /permission_template|permission_grants/i.test(message);
}

function normalizeCityBranchRows(rows: any[] | null | undefined) {
  return (rows ?? []).map((row) => ({
    permission_template: row.permission_template ?? "city-standard",
    permission_grants: Array.isArray(row.permission_grants) ? row.permission_grants : [],
    ...row
  }));
}

function buildCityBranchQuery(
  supabase: any,
  selectColumns: string,
  id: string | null,
  countryId: string | null,
  countryBranchId: string | null,
  session: Awaited<ReturnType<typeof requireErpSession>>
) {
  let query = supabase
    .from("city_branches")
    .select(selectColumns)
    .is("deleted_at", null)
    .order("created_at", { ascending: true });

  if (id && isUuid(id)) {
    query = query.eq("id", id);
  }

  if (countryId) {
    if (!session.isSuperAdmin && !session.countryIds.includes(countryId)) {
      return null;
    }
    query = query.eq("country_id", countryId);
  } else if (!session.isSuperAdmin) {
    query = query.in(
      "country_id",
      session.countryIds.length ? session.countryIds : ["00000000-0000-0000-0000-000000000000"]
    );
  }

  if (countryBranchId) {
    query = query.eq("country_branch_id", countryBranchId);
  }

  return query;
}

export async function GET(request: Request) {
  try {
    const session = await requireErpSession();
    const url = new URL(request.url);
    const id = url.searchParams.get("id");
    const countryId = url.searchParams.get("countryId");
    const countryBranchId = url.searchParams.get("countryBranchId");

    const supabase = createSupabaseAdminClient() as any;
    let query = buildCityBranchQuery(supabase, cityBranchSelect, id, countryId, countryBranchId, session);
    if (!query) return NextResponse.json({ cityBranches: [] }, { status: 200 });

    let { data, error } = await query;
    if (error && isMissingOptionalColumn(error.message)) {
      const fallbackQuery = buildCityBranchQuery(supabase, cityBranchFallbackSelect, id, countryId, countryBranchId, session);
      const fallbackResult = fallbackQuery ? await fallbackQuery : { data: [], error: null };
      data = fallbackResult.data;
      error = fallbackResult.error;
    }

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }

    return NextResponse.json({ cityBranches: normalizeCityBranchRows(data) }, { status: 200 });
  } catch (error) {
    if (error instanceof ErpAuthError) {
      return NextResponse.json({ error: error.message }, { status: error.status });
    }
    return NextResponse.json({ error: error instanceof Error ? error.message : "Server error" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await requireErpSession();
    const parsed = createCityBranchSchema.safeParse(await request.json());

    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    }

    // Super Admin can create everywhere. Country/Main branch roles can create under their country scope.
    if (!session.isSuperAdmin && !session.countryIds.includes(parsed.data.countryId)) {
      return NextResponse.json({ error: "Country scope is not allowed." }, { status: 403 });
    }

    const supabase = createSupabaseAdminClient() as any;

    const { data: mainBranch, error: mainBranchError } = await supabase
      .from("country_branches")
      .select("id,country_id,local_currency")
      .eq("id", parsed.data.countryBranchId)
      .is("deleted_at", null)
      .single();

    if (mainBranchError || !mainBranch?.id) {
      return NextResponse.json({ error: "Main branch not found." }, { status: 404 });
    }

    if (String(mainBranch.country_id) !== parsed.data.countryId) {
      return NextResponse.json({ error: "Main branch does not belong to selected country." }, { status: 400 });
    }

    // Prevent duplicate city branches under the same main branch for the same city.
    if (parsed.data.cityId) {
      const { data: existingByCityId } = await supabase
        .from("city_branches")
        .select("id")
        .eq("country_branch_id", parsed.data.countryBranchId)
        .eq("city_id", parsed.data.cityId)
        .is("deleted_at", null)
        .maybeSingle();

      if (existingByCityId?.id) {
        return NextResponse.json(
          { error: "A City Branch already exists for this City under the selected Main Branch." },
          { status: 409 }
        );
      }
    }

    const payload = {
      country_id: parsed.data.countryId,
      country_branch_id: parsed.data.countryBranchId,
      city_name: (parsed.data.cityName ?? "").trim(),
      name: parsed.data.name.trim(),
      code: parsed.data.code.trim().toUpperCase(),
      local_currency: parsed.data.currencyCode.trim().toUpperCase(),
      status: "active",
      state_province_id: parsed.data.stateProvinceId ?? null,
      city_id: parsed.data.cityId ?? null,
      area_location_id: parsed.data.areaLocationId ?? null,
      address: parsed.data.address?.trim() ? parsed.data.address.trim() : null,
      phone: parsed.data.phone?.trim() ? parsed.data.phone.trim() : null,
      email: parsed.data.email?.trim() ? parsed.data.email.trim().toLowerCase() : null,
      company_id: parsed.data.companyId ?? null,
      owner_name: parsed.data.ownerName?.trim() ? parsed.data.ownerName.trim() : null,
      contacts: parsed.data.contacts ?? [],
      documents: parsed.data.documents ?? [],
      permission_template: parsed.data.permissionTemplate ?? null,
      permission_grants: parsed.data.permissionGrants,
      created_by: isUuid(session.userId) ? session.userId : null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    // If city_id is present, prefer the canonical city name from centralized location.
    if (payload.city_id && (!payload.city_name || payload.city_name.length < 2)) {
      const { data: cityRow } = await supabase
        .from("cities")
        .select("name")
        .eq("id", payload.city_id)
        .is("deleted_at", null)
        .maybeSingle();
      if (cityRow?.name) payload.city_name = String(cityRow.name).trim();
    }

    const { data, error } = await supabase.from("city_branches").insert(payload).select("id").single();

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }

    await auditApiAction(request as any, {
      action: "city_branches.create.api",
      entityTable: "city_branches",
      entityId: data?.id ?? null,
      after: payload
    });

    return NextResponse.json({ id: data?.id }, { status: 201 });
  } catch (error) {
    if (error instanceof ErpAuthError) {
      return NextResponse.json({ error: error.message }, { status: error.status });
    }
    return NextResponse.json({ error: error instanceof Error ? error.message : "Server error" }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const session = await requireErpSession();
    const body = await request.json();
    const id = typeof body?.id === "string" ? body.id : "";
    if (!isUuid(id)) {
      return NextResponse.json({ error: "Valid city branch id is required." }, { status: 400 });
    }

    const parsed = createCityBranchSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    }

    if (!session.isSuperAdmin && !session.countryIds.includes(parsed.data.countryId)) {
      return NextResponse.json({ error: "Country scope is not allowed." }, { status: 403 });
    }

    const supabase = createSupabaseAdminClient() as any;

    const { data: mainBranch, error: mainBranchError } = await supabase
      .from("country_branches")
      .select("id,country_id,local_currency")
      .eq("id", parsed.data.countryBranchId)
      .is("deleted_at", null)
      .single();

    if (mainBranchError || !mainBranch?.id) {
      return NextResponse.json({ error: "Main branch not found." }, { status: 404 });
    }

    if (String(mainBranch.country_id) !== parsed.data.countryId) {
      return NextResponse.json({ error: "Main branch does not belong to selected country." }, { status: 400 });
    }

    if (parsed.data.cityId) {
      const { data: existingByCityId } = await supabase
        .from("city_branches")
        .select("id")
        .eq("country_branch_id", parsed.data.countryBranchId)
        .eq("city_id", parsed.data.cityId)
        .neq("id", id)
        .is("deleted_at", null)
        .maybeSingle();

      if (existingByCityId?.id) {
        return NextResponse.json(
          { error: "A City Branch already exists for this City under the selected Main Branch." },
          { status: 409 }
        );
      }
    }

    const payload = {
      country_id: parsed.data.countryId,
      country_branch_id: parsed.data.countryBranchId,
      city_name: (parsed.data.cityName ?? "").trim(),
      name: parsed.data.name.trim(),
      code: parsed.data.code.trim().toUpperCase(),
      local_currency: parsed.data.currencyCode.trim().toUpperCase(),
      status: "active",
      state_province_id: parsed.data.stateProvinceId ?? null,
      city_id: parsed.data.cityId ?? null,
      area_location_id: parsed.data.areaLocationId ?? null,
      address: parsed.data.address?.trim() ? parsed.data.address.trim() : null,
      phone: parsed.data.phone?.trim() ? parsed.data.phone.trim() : null,
      email: parsed.data.email?.trim() ? parsed.data.email.trim().toLowerCase() : null,
      company_id: parsed.data.companyId ?? null,
      owner_name: parsed.data.ownerName?.trim() ? parsed.data.ownerName.trim() : null,
      contacts: parsed.data.contacts ?? [],
      documents: parsed.data.documents ?? [],
      permission_template: parsed.data.permissionTemplate ?? null,
      permission_grants: parsed.data.permissionGrants,
      updated_at: new Date().toISOString()
    };

    if (payload.city_id && (!payload.city_name || payload.city_name.length < 2)) {
      const { data: cityRow } = await supabase
        .from("cities")
        .select("name")
        .eq("id", payload.city_id)
        .is("deleted_at", null)
        .maybeSingle();
      if (cityRow?.name) payload.city_name = String(cityRow.name).trim();
    }

    const { data, error } = await supabase
      .from("city_branches")
      .update(payload)
      .eq("id", id)
      .is("deleted_at", null)
      .select("id")
      .single();

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }

    await auditApiAction(request as any, {
      action: "city_branches.update.api",
      entityTable: "city_branches",
      entityId: data?.id ?? id,
      after: payload
    });

    return NextResponse.json({ id: data?.id ?? id }, { status: 200 });
  } catch (error) {
    if (error instanceof ErpAuthError) {
      return NextResponse.json({ error: error.message }, { status: error.status });
    }
    return NextResponse.json({ error: error instanceof Error ? error.message : "Server error" }, { status: 500 });
  }
}
